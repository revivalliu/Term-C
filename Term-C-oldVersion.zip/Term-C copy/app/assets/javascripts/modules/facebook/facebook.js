/*
var Facebook = (function(FB){
    FB.init({
        //appId      : '316323468538083', // https://intense-anchorage-6860.herokuapp.com/
        appId      : '316329491870814', //http://localhost:8081/test
        version    : 'v2.4'
    });
    FB.getLoginStatus(function(response) {
        console.log(response);
    });
}());
    */