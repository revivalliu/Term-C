var LiveLeaderboard = (function ($) {
    function leaderboard(options) {
        this.list = {};
    }

    leaderboard.prototype = {
        addToList: function (playerId, username, size) {
            this.list[playerId] = {username: username, size: size};
        },

        removeFromList: function (playerId) {
            console.log(this.list);
            delete this.list[playerId];
        },
        update: function (playerId, username, size) {
            var newEntry = true;
            var array;
            var top10;

            //add player to hash table
            this.addToList(playerId, username, size);
            //this.list[playerId] = {username:username, size:size};

            /*****test data***/
                //this.list[20] = {username:"700", size:700};
                //this.list[21] = {username:"1000", size:1000};
                //this.list[22] = {username:"600", size:600};
                //this.list[30] = {username:"700", size:700};
                //this.list[24] = {username:"650", size:650};
                //this.list[25] = {username:"400", size:400};
                //this.list[26] = {username:"50", size:50};
                //this.list[27] = {username:"1791", size:1791};
                //this.list[28] = {username:"500", size:500};
                //this.list[5] = {username:"1790", size:1790};
                //this.list[3] = {username:"2000", size:2000};

            array = sort(this.list);
            top10 = getTop10Names(array);
            updateLeaderboard(top10);
        }
    };

    //simple bubble sort
    function sort(list) {
        keys = Object.keys(list);
        var swap;

        var listArray = [];

        for (var id in list) {
            listArray.push(list[id]);
        }
        for (var i = 0; i < listArray.length; i++) {
            for (var j = 0; j < listArray.length - 1; j++) {
                if (listArray[j].size < listArray[j + 1].size) {
                    swap = listArray[j];
                    listArray[j] = listArray[j + 1];
                    listArray[j + 1] = swap;
                }
            }
        }
        return listArray;
    }

    //clear/update orderedlist on html page
    function updateLeaderboard(array) {
        $("#liveLeaderboard ol").empty();
        for (var i = 0; i < 10; i++) {
            if (array[i] != undefined) {
                $("#liveLeaderboard ol").append('<li class="list">' + array[i] + '</li>');
            }
        }
    }

    //retrieve the top 10 names on the leaderboard
    function getTop10Names(array) {
        var top10 = [];
        for (var i = 0; i < array.length && i < 10; i++) {
            if (array[i].username === "") {
                top10.push("no name");
            }
            else {
                top10.push(array[i].username);
            }
        }
        return top10;
    }

    return leaderboard;
}(jQuery));