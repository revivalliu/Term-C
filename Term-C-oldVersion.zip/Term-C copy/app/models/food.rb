class Food < ActiveRecord::Base
  belongs_to :server
end
