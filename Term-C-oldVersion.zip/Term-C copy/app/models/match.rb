class Match < ActiveRecord::Base
  belongs_to :session
end
